#!/usr/bin/env python

from __future__ import print_function
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import os
import sys
import binascii
import datetime
import subprocess
import re
import time
import threading
import string

from dumpcan import dumpcan
from time import strftime, localtime, sleep
from threading import Thread, Timer

sd_write = xbmcgui.ControlLabel(300, 30, 50, 60, 'SD', '60', '0xFFB22222')
sd_read = xbmcgui.ControlLabel(300, 30, 50, 60, 'SD', '60', '0xFF22B26A')

now = datetime.datetime.now()
data = now.strftime("%d.%m.%Y")
tm = now.strftime("%H.%M.%S")

def logcan():
    while True:
        logdir = '/home/pi/rnslogs'
        logcan = xbmcgui.Window(10000).getProperty('logcan')
        if logcan == 'true':
            if not os.path.isdir(logdir):
                os.mkdir(logdir)
            if not os.path.isdir(logdir + '/' + data):
                os.mkdir(logdir + '/' + data)
            os.system('candump can0 -t A -a -n 5000 -e -x | sudo tee ' + logdir + '/' + data + '/' + 'log_' + tm + '.txt')
            xbmcgui.Window(10000).setProperty('logcan', 'false')
            xbmc.executebuiltin('Notification($LOCALIZE[350014], , 2500)')
        time.sleep(1)


def overlayfs():
    commands = ("df -h",)
    for command in commands:
        file = (os.popen(command).read()+"\n")
        if 'devtmpfs' in file:
            xbmcgui.Window(10000).addControl(sd_write)
        elif 'overlay' in file:
            xbmcgui.Window(10000).addControl(sd_read)
        while True:
            overlayfs = xbmcgui.Window(10000).getProperty('overlayfs')
            if overlayfs == 'true':
                xbmc.executebuiltin('Notification($LOCALIZE[20186], $LOCALIZE[13013])')
                os.system('sudo raspi-config --enable-overlayfs && sudo reboot')
            elif overlayfs == 'false':
                xbmc.executebuiltin('Notification($LOCALIZE[20186], $LOCALIZE[13013])')
                os.system('sudo raspi-config --disable-overlayfs && sudo reboot')
            time.sleep(1)
            
if __name__ == '__main__':
    xbmc.executebuiltin('ActivateWindow(Home)')
    Thread(target = dumpcan).start()
    Thread(target = logcan).start()
    Thread(target = overlayfs).start()

